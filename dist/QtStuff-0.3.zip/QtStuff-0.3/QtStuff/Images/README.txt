These icons are available for use with QtStuff.

Most icons are loaded into the QtStuff library as QIcons.

'cmaps' contains pictures of every colormap available in matplotlib
'GreyCircles' contains a set of nice icons with a circular, grey background. Most of these icons are available within QtStuff with two states: 'plain' and 'halo' for hovering/selecting.
The 'halo' state displays a white 'halo' or glow around the image.

Misc contains various images, most of which are usually waiting to be added to the GreyCircle set.
Orange icons has a variety of icons designed to compliment 'GreyCircles' and are, obviously, mainly orange. 

Finally, the JBA logo is provided